import { appendFileSync, existsSync, mkdirSync, renameSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR ?? join(__dirname, '../../../data');
const LOG_DIR = join(DATA_DIR, 'logs');
const LOG_FILE = join(LOG_DIR, 'app.log');
const MAX_BYTES = 10 * 1024 * 1024; // 10 MB

try {
  mkdirSync(LOG_DIR, { recursive: true });
} catch {
  // If we can't create the log directory, file logging will be silently skipped
}

function rotateIfNeeded() {
  try {
    if (!existsSync(LOG_FILE)) return;
    if (statSync(LOG_FILE).size < MAX_BYTES) return;
    renameSync(LOG_FILE, `${LOG_FILE}.1`);
  } catch {
    // Rotation failure is non-fatal
  }
}

function writeToFile(line) {
  try {
    rotateIfNeeded();
    appendFileSync(LOG_FILE, line + '\n', 'utf8');
  } catch {
    // File write failure is non-fatal — console output still works
  }
}

export function writeLog(level, message, meta = {}) {
  const entry = {
    level,
    message,
    service: 'enem-redacoes-backend',
    timestamp: new Date().toISOString(),
    ...meta,
  };
  const line = JSON.stringify(entry);

  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);

  writeToFile(line);
}
