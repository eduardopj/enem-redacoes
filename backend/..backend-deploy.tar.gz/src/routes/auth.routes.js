import { Router } from 'express';
import { validateBody } from '../middleware/validate.js';
import { registerTeacher, savePushToken } from '../services/auth.service.js';
import { requireAuth } from '../middleware/auth.js';
import { RegisterTeacherSchema } from '../validators/auth.validators.js';

const router = Router();

router.post('/register', validateBody(RegisterTeacherSchema), (req, res) => {
  try {
    const { teacherId, teacherEmail, teacherName } = req.body;
    const token = registerTeacher(teacherId, teacherEmail, teacherName);
    res.json({ success: true, data: { token } });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: { code: 'REGISTER_ERROR', message: 'Não foi possível registrar o dispositivo.' },
    });
  }
});

// Salva o Expo push token do professor autenticado
router.post('/push-token', requireAuth, (req, res) => {
  try {
    const { pushToken } = req.body;
    if (!pushToken || typeof pushToken !== 'string') {
      return res.status(400).json({ success: false, error: { code: 'INVALID_TOKEN', message: 'pushToken inválido.' } });
    }
    savePushToken(req.teacherId, pushToken);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: { code: 'PUSH_TOKEN_ERROR', message: 'Erro ao salvar push token.' } });
  }
});

export { router as authRoutes };
