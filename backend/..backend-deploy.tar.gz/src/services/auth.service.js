import { randomBytes } from 'node:crypto';
import db from './database.js';

const TOKEN_TTL_MS = 365 * 24 * 60 * 60 * 1000; // 1 year
const RENEW_WITHIN_MS = 7 * 24 * 60 * 60 * 1000; // renew if expiring within 7 days

function generateToken() {
  return randomBytes(32).toString('hex');
}

/**
 * Registra um professor e retorna o token.
 * Idempotente: se já existir e não estiver vencendo, retorna o token existente.
 * Renova automaticamente se o token estiver vencendo em menos de 7 dias.
 */
export function registerTeacher(teacherId, teacherEmail, teacherName) {
  const existing = db
    .prepare('SELECT token, expiresAt FROM teachers WHERE teacherId = ?')
    .get(teacherId);

  if (existing) {
    // Legacy rows without expiresAt are considered valid indefinitely
    if (!existing.expiresAt) return existing.token;

    const expiresAt = new Date(existing.expiresAt);
    const renewBefore = new Date(Date.now() + RENEW_WITHIN_MS);

    // Token is still valid and not close to expiry — reuse it
    if (expiresAt > renewBefore) return existing.token;

    // Renew expiring/expired token
    const token = generateToken();
    const newExpiresAt = new Date(Date.now() + TOKEN_TTL_MS).toISOString();
    db.prepare('UPDATE teachers SET token = ?, expiresAt = ? WHERE teacherId = ?')
      .run(token, newExpiresAt, teacherId);
    return token;
  }

  const token = generateToken();
  const expiresAt = new Date(Date.now() + TOKEN_TTL_MS).toISOString();
  db.prepare(
    'INSERT INTO teachers (teacherId, teacherEmail, teacherName, token, expiresAt) VALUES (?, ?, ?, ?, ?)'
  ).run(teacherId, teacherEmail ?? '', teacherName ?? '', token, expiresAt);
  return token;
}

/**
 * Salva ou atualiza o push token Expo de um professor.
 */
export function savePushToken(teacherId, pushToken) {
  db.prepare('UPDATE teachers SET pushToken = ? WHERE teacherId = ?')
    .run(pushToken ?? null, teacherId);
}

/**
 * Retorna o push token Expo do professor, ou null se não registrado.
 */
export function getTeacherPushToken(teacherId) {
  const row = db.prepare('SELECT pushToken FROM teachers WHERE teacherId = ?').get(teacherId);
  return row?.pushToken ?? null;
}

/**
 * Valida o bearer token e retorna o teacher, ou null se inválido/expirado.
 */
export function validateToken(token) {
  if (!token || token.length !== 64) return null;
  const teacher = db
    .prepare('SELECT teacherId, teacherEmail, expiresAt FROM teachers WHERE token = ?')
    .get(token);
  if (!teacher) return null;
  // Legacy rows without expiresAt remain valid
  if (teacher.expiresAt && new Date(teacher.expiresAt) < new Date()) return null;
  return { teacherId: teacher.teacherId, teacherEmail: teacher.teacherEmail };
}
