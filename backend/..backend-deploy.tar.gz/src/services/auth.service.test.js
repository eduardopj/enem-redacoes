import { randomBytes } from 'node:crypto';
import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import Database from 'better-sqlite3';

// In-memory DB — mirrors the schema from database.js
function createTestDb() {
  const db = new Database(':memory:');
  db.exec(`
    CREATE TABLE IF NOT EXISTS teachers (
      teacherId    TEXT PRIMARY KEY,
      teacherEmail TEXT,
      teacherName  TEXT,
      token        TEXT NOT NULL UNIQUE,
      createdAt    TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  return db;
}

// Service logic under test (extracted to be testable with injected db)
function makeAuthService(db) {
  function generateToken() {
    return randomBytes(32).toString('hex');
  }

  function registerTeacher(teacherId, teacherEmail, teacherName) {
    const existing = db.prepare('SELECT token FROM teachers WHERE teacherId = ?').get(teacherId);
    if (existing) return existing.token;
    const token = generateToken();
    db.prepare(
      'INSERT INTO teachers (teacherId, teacherEmail, teacherName, token) VALUES (?, ?, ?, ?)'
    ).run(teacherId, teacherEmail ?? '', teacherName ?? '', token);
    return token;
  }

  function validateToken(token) {
    if (!token || token.length !== 64) return null;
    return db.prepare('SELECT teacherId, teacherEmail FROM teachers WHERE token = ?').get(token) ?? null;
  }

  return { registerTeacher, validateToken };
}

describe('registerTeacher', () => {
  let db;
  let service;

  before(() => {
    db = createTestDb();
    service = makeAuthService(db);
  });

  it('returns a 64-char hex token', () => {
    const token = service.registerTeacher('t1', 'a@b.com', 'Ana');
    assert.equal(typeof token, 'string');
    assert.equal(token.length, 64);
    assert.ok(/^[0-9a-f]+$/.test(token));
  });

  it('is idempotent — same teacher returns same token', () => {
    const token1 = service.registerTeacher('t2', 'b@c.com', 'Bruno');
    const token2 = service.registerTeacher('t2', 'b@c.com', 'Bruno');
    assert.equal(token1, token2);
  });

  it('different teachers get different tokens', () => {
    const token1 = service.registerTeacher('t3', 'c@d.com', 'Carla');
    const token2 = service.registerTeacher('t4', 'd@e.com', 'Diego');
    assert.notEqual(token1, token2);
  });
});

describe('validateToken', () => {
  let db;
  let service;

  before(() => {
    db = createTestDb();
    service = makeAuthService(db);
  });

  it('returns teacher info for a valid token', () => {
    const token = service.registerTeacher('v1', 'v@test.com', 'Valid');
    const result = service.validateToken(token);
    assert.ok(result !== null);
    assert.equal(result.teacherId, 'v1');
    assert.equal(result.teacherEmail, 'v@test.com');
  });

  it('returns null for an unknown token', () => {
    const fakeToken = 'a'.repeat(64);
    assert.equal(service.validateToken(fakeToken), null);
  });

  it('returns null for token shorter than 64 chars', () => {
    assert.equal(service.validateToken('abc'), null);
  });

  it('returns null for empty token', () => {
    assert.equal(service.validateToken(''), null);
  });

  it('returns null for null/undefined', () => {
    assert.equal(service.validateToken(null), null);
    assert.equal(service.validateToken(undefined), null);
  });
});
