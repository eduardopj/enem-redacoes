import { z } from 'zod';

export const RegisterTeacherSchema = z.object({
  teacherId:    z.string().min(1).max(100),
  teacherEmail: z.string().max(254).optional().or(z.literal('')),
  teacherName:  z.string().min(1).max(200),
});
