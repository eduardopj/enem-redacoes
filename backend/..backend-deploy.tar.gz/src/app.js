import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import { randomUUID } from 'node:crypto';
import { env } from './config/env.js';
import { requireAuth } from './middleware/auth.js';
import { authRoutes } from './routes/auth.routes.js';
import { openAiRoutes } from './routes/openai.routes.js';
import { researchRoutes } from './routes/research.routes.js';
import { syncRoutes } from './routes/sync.routes.js';
import { getQueueStats } from './utils/correction-queue.js';
import { writeLog } from './utils/logger.js';
import { captureException } from './utils/sentry.js';

const app = express();

function isOriginAllowed(origin) {
  if (!origin) return true;
  if (env.corsOrigins.includes('*')) return true;
  return env.corsOrigins.includes(origin);
}

app.use(
  cors({
    origin(origin, callback) {
      if (isOriginAllowed(origin)) return callback(null, true);
      return callback(new Error('Origem não permitida pelo CORS.'));
    },
    methods: ['GET', 'POST', 'PUT', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-Id'],
    exposedHeaders: ['X-Request-Id'],
  })
);

app.use((req, res, next) => {
  req.requestId = String(req.headers['x-request-id'] || randomUUID());
  res.setHeader('X-Request-Id', req.requestId);
  next();
});

app.use(express.json({ limit: env.requestBodyLimit }));
app.use(express.urlencoded({ extended: true, limit: env.requestBodyLimit }));

app.get('/health', (req, res) => {
  res.json({
    success: true,
    requestId: req.requestId,
    data: {
      ok: true,
      service: 'enem-redacoes-backend',
      timestamp: new Date().toISOString(),
      queue: getQueueStats(),
    },
  });
});

app.use((req, res, next) => {
  const startedAt = Date.now();
  res.on('finish', () => {
    writeLog(res.statusCode >= 500 ? 'error' : 'info', 'request_finished', {
      requestId: req.requestId,
      method: req.method,
      path: req.originalUrl,
      status: res.statusCode,
      durationMs: Date.now() - startedAt,
    });
  });
  next();
});

const correctionLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: (_req, res) => ({
    success: false,
    requestId: res.req?.requestId,
    error: {
      code: 'RATE_LIMITED',
      message: 'Muitas correções em pouco tempo. Aguarde alguns minutos e tente novamente.',
    },
  }),
});

// /sync/turmas/by-code/:code is public (students join without teacher token).
// All other /sync and /openai routes require Bearer token.
function syncAuth(req, res, next) {
  if (req.method === 'GET' && req.path.startsWith('/turmas/by-code/')) return next();
  return requireAuth(req, res, next);
}

// ── v1 routes (canonical) ────────────────────────────────────────────────────
app.use('/v1/auth', authRoutes);
app.use('/v1/research', researchRoutes);
app.use('/v1/sync', syncAuth, syncRoutes);
app.use('/v1/openai/correct-essay', correctionLimiter);
app.use('/v1/openai', requireAuth, openAiRoutes);

// ── Legacy routes (backward-compat for older app builds) ─────────────────────
app.use('/auth', authRoutes);
app.use('/research', researchRoutes);
app.use('/sync', syncAuth, syncRoutes);
app.use('/openai/correct-essay', correctionLimiter);
app.use('/openai', requireAuth, openAiRoutes);

app.use((err, req, res, _next) => {
  captureException(err, { requestId: req.requestId, path: req.originalUrl });
  writeLog('error', 'unhandled_error', {
    requestId: req.requestId,
    method: req.method,
    path: req.originalUrl,
    error: err?.message ?? String(err),
  });

  if (err?.type === 'entity.too.large') {
    return res.status(413).json({
      success: false,
      requestId: req.requestId,
      error: {
        code: 'PAYLOAD_TOO_LARGE',
        message: 'A imagem enviada é muito grande. Tire uma nova foto ou reduza o arquivo.',
      },
    });
  }

  return res.status(500).json({
    success: false,
    requestId: req.requestId,
    error: {
      code: 'INTERNAL_ERROR',
      message: 'O servidor não conseguiu concluir a operação. Tente novamente.',
    },
  });
});

export { app };
